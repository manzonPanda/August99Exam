<?php
require_once("connectDB.php");
$isbn = ($_POST['isbn']);

//sql
$sqlDelete = mysqli_query($con,"Delete from books where isbn='$isbn'");

?>