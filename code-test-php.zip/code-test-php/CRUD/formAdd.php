<?php
require_once("connectDB.php");

$titleBook = ($_POST['titleBook']);
$isbn = ($_POST['isbn']);
$author = ($_POST['author']);
$publisher = ($_POST['publisher']);
$yearPublished = ($_POST['yearPublished']);
$bookCategory = ($_POST['bookCategory']);

$sqlResult = mysqli_query($con,"insert into books(title,isbn,author,publisher,year_published,category) values ('$titleBook','$isbn','$author','$publisher','$yearPublished','$bookCategory')");

// reload,return back to home page
header('location:index.html');


?>