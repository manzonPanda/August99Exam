<?php
require_once("connectDB.php");
$isbn = ($_POST['isbn']);
$newTitleBook = ($_POST['newTitleBook']);
$newAuthor = ($_POST['newAuthor']);
$newPublisher = ($_POST['newPublisher']);
$yearPublishedNew = ($_POST['yearPublishedNew']);
$newBookCategory = ($_POST['newBookCategory']);

//sql
$sqlResult = mysqli_query($con,"update books set title='$newTitleBook', author='$newAuthor',publisher='$newPublisher',year_published='$yearPublishedNew',category='$newBookCategory' where isbn='$isbn'");

?>